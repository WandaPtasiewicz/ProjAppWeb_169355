function changeBackground(hexNumber)
{
    document.body.style.backgroundColor = hexNumber;
}